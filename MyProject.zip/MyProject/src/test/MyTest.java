package test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;

public class MyTest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		MyTest testObject = new MyTest();
		
		testObject.testMethod();
		
		

	}
	
	private void testMethod() throws IOException{
		InputStream reader = getClass().getClassLoader().getResourceAsStream("configurations.properties");
		Properties properties = new Properties();
		properties.load(reader);
		Enumeration<?> enumProperties = properties.keys();
		int lineNumber = 1;
		while(enumProperties.hasMoreElements()){
			String key = enumProperties.nextElement().toString();
			System.out.println(lineNumber +".\tPropertyName : "+key+"\t\t Property Value : "+properties.getProperty(key));
			lineNumber++;
		}
	}

}
