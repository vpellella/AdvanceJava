package test;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.Properties;

public class BaseConfigurations {

	private String driverClass = new String();
	private String Url = new String();
	private String databaseUserName = new String();
	private String databasePassword = new String();
	private Properties properties = new Properties();
	private Connection connection;
			
	/*	@Author : Vineel Pellella
	 * 	Email : vineel.royal@gmail.com
	 * 	Method Name : getPropertiesFromPropertiesFile
	 * 	Usage : This method helps to read the configurations from configurations.properties
	 * 	return : Properties
	 */
	
	public Properties getPropertiesFromPropertiesFile() throws IOException{
		System.out.println("============readConfigurations Method Started============");
		InputStream reader = getClass().getClassLoader().getResourceAsStream("configurations.properties");
			properties.load(reader);
		Enumeration<?> enumProperties = properties.keys();
		int lineNumber = 1;
		while(enumProperties.hasMoreElements()){
			String key = enumProperties.nextElement().toString();
			System.out.println(lineNumber +".\tPropertyName : "+key+"\t\t Property Value : "+properties.getProperty(key));
			lineNumber++;
		}
		System.out.println("============readConfigurations Method Ended============");
		return properties;
	}
	

	
	
	
	
	
	
	public void connectToDataBase() throws Exception{
		System.out.println("============connectToDataBase Method Started============");
		//Getting details for Database Connection
		driverClass = properties.getProperty("DriverClass");
		Url = "jdbc:"+properties.getProperty("DriverName")+":thin:@"+properties.getProperty("Host")+":"+properties.getProperty("PortNumber")+":"+properties.getProperty("ServiceProvider");
		databaseUserName = properties.getProperty("UserName");
		databasePassword = properties.getProperty("Password");
		//String createTableQuery = "Create Table "+properties.getProperty("DataBaseTableName")+"(rollNumber varchar2(10) , name varchar2(20))";
		
		//Loading Of Driver
		Class.forName(driverClass);
		System.out.println("Driver : "+ driverClass);
		//Getting Connection
		connection = DriverManager.getConnection(Url, databaseUserName , databasePassword);
		System.out.println("+++connection Established"+ connection);
		Statement statement = connection.createStatement();
		
		//Verifying the Table is present Or Not if absent throw exception table not present
		//Currently i am creating a new table
		DatabaseMetaData databaseMetaData= connection.getMetaData();
		ResultSet databaseTables= databaseMetaData.getTables(null, null, null,new String[] {"TABLE"});
		boolean tableNameStatus = false;
		String databaseTableName = properties.getProperty("DataBaseTableName");
		//System.out.println("++DataBase Table Name :: "+databaseTableName);
		int rollNumberColumnNumber = 0;
		while(databaseTables.next()){
			for(int columnCount=0; columnCount< databaseTables.getMetaData().getColumnCount() ;columnCount++){
				String DBTableName = databaseTables.getString(columnCount+1);
				//System.out.println("DB Table Name:: " + DBTableName);
				if(DBTableName != null && !DBTableName.isEmpty()){
					if(DBTableName.equalsIgnoreCase(databaseTableName)){
						tableNameStatus =  true ; 
						System.out.println("Presence of Table in Database : "+tableNameStatus);
						
						String columnName = databaseTables.getMetaData().getColumnName(columnCount);
						if(columnName.equalsIgnoreCase("RollNumber".trim()) || columnName.equalsIgnoreCase("Roll Number".trim()))
							rollNumberColumnNumber = columnCount;
						System.out.println("Database Roll Number Column is in "+rollNumberColumnNumber +"Column");
						break;
					}
				}
			}
		}
		if(tableNameStatus == false){
//			statement.execute(createTableQuery);
//			System.out.println("++ "+properties.getProperty("DataBaseTableName") +"Table Created Sucessfully ");
			throw new Exception("Database Table Not Present");
		}
		statement.clearBatch();
		String GetDataQuery = "select * from "+properties.getProperty("DataBaseTableName")+" where RollNo = ?";
		PreparedStatement preparedStatement = connection.prepareStatement(GetDataQuery);
		
		// Need to Modify
		preparedStatement.setInt(1, 123);
		// Need to Modify
//		ResultSet databaseTableContent = statement.executeQuery("select * from students001 where rollno = 123");
//		while(databaseTableContent.next()){
//			System.out.println("======================="+databaseTableContent.getString(0));
//		}
		ResultSet databaseTableContent = preparedStatement.executeQuery();
		System.out.println(databaseTableContent);
		ResultSetMetaData databaseTableContentMetaData = databaseTableContent.getMetaData();
		for(int iterator = 1 ; iterator < databaseTableContentMetaData.getColumnCount(); iterator++){
//			System.out.println(databaseTableContentMetaData.getColumnCount());
//			System.out.println(databaseTableContentMetaData.getColumnTypeName(iterator).equals("BLOB"));
//			databaseTableContent.get
		}
		System.out.println(databaseTableContent.next());
		for(int iterator = 1 ; iterator < databaseTableContentMetaData.getColumnCount() && databaseTableContent.next(); iterator++){
			System.out.println(databaseTableContent.getObject(iterator).getClass().getName());
//			databaseTableContent.findColumn("");
		}
		
//		Blob b=rs.getBlob(2);//2 means 2nd column data  
//		byte barr[]=b.getBytes(1,(int)b.length());//1 means first image  
//		              
//		FileOutputStream fout=new FileOutputStream("d:\\sonoo.jpg");  
//		fout.write(barr);  
//		              
//		fout.close();  
		connection.close();
		System.out.println("+++ Connection Closed Sucessfully");
		System.out.println("============connectToDataBase Method Ended============");
}
	
public static void main(String[] args) throws Exception {
	
	BaseConfigurations myresr = new BaseConfigurations();
	myresr.getPropertiesFromPropertiesFile();
	myresr.connectToDataBase();
	
}
}